import { TextField, Button } from "@mui/material";
import { useFormik } from "formik";
import React from "react";
import { Link } from "react-router-dom";
import * as yup from "yup";


function Register(){

    const registervalidationschema = yup.object({
        username :yup.string().required(),
        email:yup.string().required().email(),
        password:yup.string().required().min(8),
    })

    const formik = useFormik({
        initialValues:{
            username:"",
            email:"",
            password:"",
        },

        validationSchema : registervalidationschema,

        onSubmit: (values)=>{
            console.log(values)
        }
    })

    return(
        <form className="addForm" onSubmit={formik.handleSubmit} >
        <h1>Register</h1>
        <TextField 
            id="outlined-basic" 
            label="Username" 
            variant="outlined" 
            name="username"
            value={formik.values.username}
            onChange={formik.handleChange}
            onBlur={formik.handleBlur} 
            error={formik.touched.username && formik.errors.username}
            helperText={formik.touched.username && formik.errors.username ? formik.errors.username : null}
        />
        <TextField 
            id="outlined-basic" 
            label="Email" 
            variant="outlined" 
            name="email"
            value={formik.values.email}
            onChange={formik.handleChange}
            onBlur={formik.handleBlur} 
            error={formik.touched.email && formik.errors.email}
            helperText={formik.touched.email && formik.errors.email ? formik.errors.email : null}
        />
        <TextField 
            id="outlined-basic" 
            label="Password" 
            variant="outlined" 
            name="password" 
            value={formik.values.password}
            onChange={formik.handleChange} 
            onBlur={formik.handleBlur} 
            error={formik.touched.password && formik.errors.password}
            helperText={formik.touched.password && formik.errors.password ? formik.errors.password : null}  
        />
        <Button variant="contained" type="submit">Contained</Button>
        <h4>Already have an account ? click here <Link to='/login'>Register</Link></h4>
        </form>
    )
}

export default Register
