import { TextField,Button } from "@mui/material";
import { useFormik } from "formik";
import React from "react";
import * as yup from "yup"

function AddMovie(){

    const movievalidationschema = yup.object({
        name:yup.string().required(),
        poster:yup.string().required().min(10).url(),
        trailer:yup.string().required().min(10).url(),
        rating:yup.number().required().min(0).max(10),
        summary:yup.string().required().min(20)
    })

    const formic = useFormik({
        initialValues:{
            name:"",
            poster:"",
            trailer:"",
            rating:"",
            summary:""
        },
        validationSchema:movievalidationschema,

        onSubmit: (values)=>{
            console.log(values);
        }
    })
    return(
        <form className="addForm" onSubmit={formic.handleSubmit}>
            <h1>AddMovie</h1>
            <TextField 
            id="outlined-basic" 
            label="Name" 
            variant="outlined" 
            name="name"   
            onChange={formic.handleChange} 
            value={formic.values.name} 
            onBlur={formic.handleBlur} 
            error={formic.touched.name && formic.errors.name}
            helperText={formic.touched.name && formic.errors.name ? formic.errors.name : null}
             />

            <TextField
            id="outlined-basic"
            label="Poster" 
            variant="outlined" 
            name="poster" 
            onChange={formic.handleChange} 
            value={formic.values.poster}
            onBlur={formic.handleBlur} 
            error={formic.touched.poster && formic.errors.poster}
            helperText={formic.touched.poster && formic.errors.poster ? formic.errors.poster : null}    
            />

            <TextField 
            id="outlined-basic" 
            label="trailer" 
            variant="outlined" 
            name="trailer" 
            onChange={formic.handleChange} 
            value={formic.values.trailer}
            onBlur={formic.handleBlur} 
            error={formic.touched.trailer && formic.errors.trailer}
            helperText={formic.touched.trailer && formic.errors.trailer ? formic.errors.trailer : null}    
            />

            <TextField 
            id="outlined-basic" 
            label="rating" 
            variant="outlined" 
            name="rating" 
            onChange={formic.handleChange} 
            value={formic.values.rating}
            onBlur={formic.handleBlur} 
            error={formic.touched.rating && formic.errors.rating}
            helperText={formic.touched.ratingr && formic.errors.rating ? formic.errors.rating : null}     
            />

            <TextField 
            id="outlined-basic" 
            label="summary" 
            variant="outlined" 
            name="summary"
            onChange={formic.handleChange} 
            value={formic.values.summary}
            onBlur={formic.handleBlur} 
            error={formic.touched.summary && formic.errors.summary}
            helperText={formic.touched.summary && formic.errors.summary ? formic.errors.summary : null}     
            />

            <Button variant="contained" type="submit">Contained</Button>
            
        </form>
    )
}

export default AddMovie