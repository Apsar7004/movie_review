import { TextField,Button } from "@mui/material";
import { useFormik } from "formik";
import React from "react";
import * as yup from "yup"
import {Link} from 'react-router-dom'


function Login(){
 
    const loginvalidationschema = yup.object({
        email:yup.string().required(),
        password:yup.string().required().min(8)
    })
    const formic = useFormik({
        initialValues:{
            email:"",
            password:""
        },

        validationSchema:loginvalidationschema,

        onSubmit : (values)=>{
            console.log(values)
        }
    })
 
    return (
        <form className="addForm" onSubmit={formic.handleSubmit}>
        <h1>Login</h1>
        <TextField            
            id="outlined-basic" 
            label="Email" 
            variant="outlined" 
            name="email"   
            onChange={formic.handleChange} 
            value={formic.values.email} 
            onBlur={formic.handleBlur} 
            error={formic.touched.email && formic.errors.email}
            helperText={formic.touched.email && formic.errors.email ? formic.errors.email : null}/>
        <TextField
            id="outlined-basic" 
            label="Password" 
            variant="outlined" 
            name="password"   
            onChange={formic.handleChange} 
            value={formic.values.password} 
            onBlur={formic.handleBlur} 
            error={formic.touched.password && formic.errors.password}
            helperText={formic.touched.password && formic.errors.password ? formic.errors.password : null}/>
         <Button variant="contained" type="submit">Contained</Button>
         <h4>Dont'have an account ? click here <Link to='/register'>Register</Link></h4>
        </form>
    )
}

export default Login